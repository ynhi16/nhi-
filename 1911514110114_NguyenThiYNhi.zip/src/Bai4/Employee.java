/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Bai4;

/**
 *
 * @author pc
 */
public class Employee {
    static String eName = "Nguyễn Tuấn Anh";
    static int eID;
    static int age;
    String companyName ="ADB";
    static {
        eID = 1556;
        System.out.println("eID: "+eID);
    }
    static {
        age = 19;
        System.out.println("age: "+age);
    }
    public static void main(String[] args) {
        
    }
}
